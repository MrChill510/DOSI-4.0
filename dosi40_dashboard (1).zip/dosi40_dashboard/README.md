# DOSI-4.0 · Dashboard de monitoreo de la estación de pesaje

Dashboard web (Streamlit + Plotly) del prototipo **DOSI-4.0** (Poka-Yoke + IoT + auditoría 5S digital)
en la estación de pesaje de micro-ingredientes de una planta de alimentos balanceados.
Prototipo académico: sin nombres reales de personas ni de la empresa (operarios = `OP-01`, `OP-02`…).

> Si no se suben archivos, el tablero usa **datos simulados** con semilla fija y muestra el aviso
> **"DATOS ILUSTRATIVOS, NO SON RESULTADOS DE VALIDACIÓN"**. Esos datos no son evidencia de mejora.

---

## 1. Esquema del layout

| Zona | Contenido |
|---|---|
| **Barra lateral** | *Fuente de datos* (subir CSV de pesadas y de 5S) · *Parámetros* (umbrales del semáforo, tolerancia única opcional, semilla, n.° de pesadas, columna `periodo` de demo) · *Filtros* (fechas, turno, producto, ingrediente, operario) · botón *Restablecer filtros*. |
| **Encabezado** | Título, subtítulo y banda de aviso de datos ilustrativos (solo mientras haya datos simulados). Mensajes de validación de CSV debajo. |
| **Fila de KPIs** | 5 tarjetas: total de pesadas · % dentro de tolerancia · % de errores detectados por el Poka-Yoke · tiempo medio de ciclo · puntaje 5S global con semáforo. Cada tarjeta muestra en texto pequeño cómo se calcula. |
| **Pestaña Control del peso** | Gráfico de control (objetivo, límites, puntos fuera de rango en rojo, zoom con barra inferior) + tabla **Alertas recientes** (últimas 10 ALERTA/BLOQUEO). |
| **Pestaña Errores por tipo** | Barras por tipo de error; interruptor *Comparar turnos*. |
| **Pestaña Tendencias** | Tasa de error (%) y tiempo de ciclo medio, por día o por día y turno. |
| **Pestaña Auditoría 5S** | Radar de las 5 S con la meta y evolución del puntaje global con bandas del semáforo. |
| **Pestaña Antes vs. después** | Barras agrupadas (tasa de error, ciclo, 5S) si existe la columna `periodo`; si no, un mensaje. |
| **Pestaña Datos y alertas** | Tabla ordenable con filtro por resultado y búsqueda, botón de descarga CSV y formato esperado de los archivos. |

## 2. Árbol de archivos

```
dosi40_dashboard/
├── app.py                     # interfaz Streamlit (filtros, KPIs, pestañas)
├── config.py                  # parámetros: semilla, umbrales, paleta, esquema de columnas
├── requirements.txt
├── README.md
├── .streamlit/
│   └── config.toml            # tema claro
├── modules/
│   ├── __init__.py
│   ├── datos.py               # datos simulados + lectura y validación de CSV
│   ├── kpis.py                # filtros, KPIs y agregaciones (funciones puras)
│   └── graficos.py            # figuras Plotly
├── data/
│   ├── pesadas_ejemplo.csv        # 502 pesadas simuladas (mismo set que la app por defecto)
│   └── auditoria_5s_ejemplo.csv   # 16 auditorías simuladas
└── capturas/                  # capturas de cada pestaña (para la exposición)
```

`modules/datos.py` se agregó a la estructura pedida para que `app.py` no mezcle interfaz con
generación/validación de datos.

## 3. Formato de los CSV

**Pesadas:** `fecha_hora, turno, producto, ingrediente, lote, operario_codigo, peso_objetivo_kg,
peso_real_kg, tolerancia_pct, resultado_poka_yoke (OK/ALERTA/BLOQUEO), tipo_error, tiempo_ciclo_s,
estado_estacion` · opcional `periodo` (`antes` / `después`).

**Auditoría 5S:** `fecha, turno, seiri, seiton, seiso, seiketsu, shitsuke` (0-100) · opcional `periodo`.

Separador `,` o `;`, coma decimal aceptada, UTF-8 o Latin-1 (exportación típica de Excel).
`tipo_error` vacío se interpreta como `Ninguno`.

## 4. Instalación y ejecución

Requiere Python 3.11 o superior.

```bash
cd dosi40_dashboard
python -m venv .venv
# Windows: .venv\Scripts\activate     ·  macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

Se abre en `http://localhost:8501`. Para proyectar: menú ⋮ → *Settings* → *Wide mode* ya viene
activado; ocultar la barra lateral con `«` y usar zoom del navegador al 110-125 %.

## Definición de los KPIs

| KPI | Cálculo |
|---|---|
| Total de pesadas | N.° de registros después de aplicar los filtros. |
| % dentro de tolerancia | Pesadas con `|real − objetivo| / objetivo × 100 ≤ tolerancia_pct` ÷ total × 100. |
| % errores detectados | Errores con resultado `ALERTA` o `BLOQUEO` ÷ errores registrados (`tipo_error ≠ Ninguno`) × 100. |
| Tasa de error | Pesadas con error ÷ total de pesadas × 100 (tarjeta 3 y pestaña Tendencias). |
| Tiempo medio de ciclo | Promedio de `tiempo_ciclo_s`. |
| Puntaje 5S global | Promedio de las 5 S de las auditorías del rango de fechas y turnos filtrados. Semáforo: verde ≥ 85, ámbar 70-84, rojo < 70 (configurable). |

## 5. Pruebas manuales

| # | Prueba | Pasos | Resultado esperado |
|---|---|---|---|
| 1 | **Aviso de datos ilustrativos** | Abrir la app sin subir archivos. Luego subir `data/pesadas_ejemplo.csv` y `data/auditoria_5s_ejemplo.csv` en *Fuente de datos*. | Al inicio aparece la banda "DATOS ILUSTRATIVOS…" con 502 pesadas. Con solo un CSV subido el aviso sigue e indica qué conjunto es simulado; con ambos, desaparece. |
| 2 | **Filtros sincronizados** | Filtrar *Turno = Mañana*, luego *Producto = NUTRIMAX*. | Las 5 tarjetas, los gráficos de todas las pestañas, las alertas y la tabla cambian a la vez; la tabla muestra solo Mañana/NUTRIMAX y el total coincide con la tarjeta "Total de pesadas". |
| 3 | **Cálculo de KPIs** | Sin filtros, ir a *Datos y alertas* → descargar CSV y abrirlo en Excel. Calcular `CONTAR.SI(dentro_tolerancia;VERDADERO)/total` y los detectados/errores. | Los valores coinciden con las tarjetas (con datos simulados por defecto: 502 pesadas, 92,4 % dentro de tolerancia, 47 de 49 errores detectados = 95,9 %). |
| 4 | **Gráfico de control** | Filtrar *Ingrediente = Coccidiostato*. Pasar el cursor sobre un rombo rojo. | El eje cambia a kg con líneas de objetivo y límites; los puntos fuera de tolerancia aparecen como rombos rojos y el tooltip muestra objetivo, real, desviación y resultado. |
| 5 | **Filtro sin registros y semáforo** | Elegir *Producto = CORIMIX* e *Ingrediente = Coccidiostato* (CORIMIX no lo usa). Luego *Restablecer filtros* y en *Parámetros* poner verde = 70, ámbar = 60. | Primero aparece un mensaje amigable ("Ningún registro cumple…") y no un error. Tras restablecer, el semáforo 5S pasa de ámbar a verde con el mismo puntaje (70,8). |

Prueba adicional de robustez: subir un CSV al que se le borró la columna `tolerancia_pct` → aparece
"Faltan columnas obligatorias: tolerancia_pct" y el tablero sigue con datos simulados.
